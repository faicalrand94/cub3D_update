/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fbouibao <fbouibao@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/01 10:14:29 by fbouibao          #+#    #+#             */
/*   Updated: 2020/12/26 19:14:51 by fbouibao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char		*ft_strdup2(const char *s1)
{
	size_t	size;
	char	*str;
	int		i;

	i = 0;
	size = ft_strlen2(s1);
	if (!(str = (char*)malloc((size + 1) * sizeof(char))))
		return (NULL);
	if (!str)
		return (NULL);
	while (s1[i] != '\0')
	{
		str[i] = s1[i];
		i++;
	}
	str[i] = '\0';
	return (str);
}

char		*ft_strjoin1(t_listrd allvrbs, char *buffer, int i, int j)
{
	size_t	size;
	char	*str;

	if (!buffer)
	{
		if (!(str = ft_strdup2(allvrbs.tmp)))
		{
			free(allvrbs.tmp);
			return (NULL);
		}
		free(allvrbs.tmp);
		return (str);
	}
	size = ft_strlen2(buffer) + ft_strlen2(allvrbs.tmp);
	if (!(str = (char*)malloc(sizeof(char) * size + 1)))
		return (NULL);
	while (buffer[++i] != '\0')
		str[i] = buffer[i];
	while (allvrbs.tmp[j] != '\0')
		str[i++] = allvrbs.tmp[j++];
	str[i] = '\0';
	free(allvrbs.tmp);
	free(buffer);
	return (str);
}
