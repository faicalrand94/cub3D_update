/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fbouibao <fbouibao@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/01 15:51:26 by fbouibao          #+#    #+#             */
/*   Updated: 2020/12/26 19:14:40 by fbouibao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H

# include <stdlib.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <unistd.h>
# include <string.h>
# include <stdio.h>

typedef	struct	s_listrd
{
	char			*tmp;
	int				fd;
	int				b;
	int					read_rtn;
}				t_listrd;

char		*ft_strjoin1(t_listrd allvrbs, char *buffer, int i, int j);
size_t			ft_strlen2(const char *str);
char			*ft_strdup2(const char *s1);
char			*get_line(char **buffer, int r, int fd);
int				is_b_n(char *str);
int				get_next_line(int fd, char **line);
int				n_get_l(char **buffer, char **str, int fd, int i);
int				norme_lines(int fd, char **buffer, char **line, int *read_rtn);
int				nrm_l(int fd, char **tmp, int *read_rtn, char **line);

#endif
