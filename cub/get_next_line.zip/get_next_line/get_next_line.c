/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fbouibao <fbouibao@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/01 14:33:04 by fbouibao          #+#    #+#             */
/*   Updated: 2020/12/28 18:29:47 by fbouibao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"
# define BUFFER_SIZE 1


size_t		ft_strlen2(const char *str)
{
	int cpt;

	cpt = 0;
	while (str[cpt] != '\0')
	{
		cpt++;
	}
	return (cpt);
}

int			is_b_n(char *str)
{
	int		i;
	
	if (!str)
		return (0);
	i = -1;
	while (str[++i])
		if (str[i] == '\n')
			return (1);
	return (0);
}

int			get_next_line(int fd, char **line)
{
	
	t_listrd    allvrbs;
    static char			*buffer;

	while (1)
    {
        if (!(allvrbs.tmp = (char*)malloc(sizeof(char) * (BUFFER_SIZE + 1))))
		    allvrbs.read_rtn = -1;
        if ((allvrbs.read_rtn = read(fd, allvrbs.tmp, BUFFER_SIZE)) == -1)
            return (-1);
        allvrbs.tmp[allvrbs.read_rtn] = '\0';
        if (is_b_n(allvrbs.tmp))
        {
            free(allvrbs.tmp);
            break ;
        }
            
        buffer = ft_strjoin1(allvrbs, buffer, -1, 0);
        
        if (allvrbs.read_rtn == 0)
        {
            break;
        }
    }
    if (!buffer)
    {
        *line = ft_strdup2("\0");
        return (1);
    }
    *line = ft_strdup2(buffer);
    free(buffer);
    buffer = NULL;
    if (allvrbs.read_rtn == 0)
        return (0);
	return (1);
}
// int main()
// {
//     char        *line;
//     int         rd;
//     int         fd;

//     fd = open("map.cub", O_RDONLY);
//     while ((rd = get_next_line(fd, &line)) >= 0)
//     {
// 		printf("%d ====> %s\n", rd,line);
//         if (!rd)
//             break ;
// 	}

// }